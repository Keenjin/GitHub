import socket, struct


def get_host_ip():
    s = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        if s:
            s.close()
    return ip


def ip2num(ip):
    return struct.unpack("!L", socket.inet_aton(ip))[0]


def num2ip(num):
    return socket.inet_ntoa(struct.pack('!L', num))


# if __name__ == '__main__':
#     print(num2ip(123456789))


