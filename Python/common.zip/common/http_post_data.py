#!/usr/bin/env python3
# coding=utf-8

import json
import urllib
from urllib import request
from abc import ABCMeta, abstractmethod
from http.server import BaseHTTPRequestHandler, HTTPServer
import hashlib
import pickle

from src.common import txlog
from src.common import helpapi

logger = txlog.getTxLogger()


# 客户端使用此类发数据，不做数据的正确校验，由上层来做校验
class HttpPoster(object):
    def __init__(self, ip, port, try_cnt=1):
        self.ip = ip
        self.port = helpapi.normalize_port(port)
        self.url = helpapi.normalize_host(self.ip) + ":" + str(self.port)
        self.try_cnt = try_cnt

    def post_data(self, data, check_data=True, timeout=5):
        if isinstance(data, dict):
            data = json.dumps(data)
        elif not isinstance(data, str):
            return None
        result = None
        logger.info("post data: %s", data)
        req = request.Request(self.url)
        req.add_header('Content-Type', 'application/json')
        data_dict = {}
        data_dict["data"] = data
        if check_data:
            data_dict["md5"] = hashlib.md5(data.encode('utf8')).hexdigest()
        sendbytes = json.dumps(data_dict).encode("utf-8")
        cnt = self.try_cnt
        while cnt > 0:
            cnt = cnt - 1
            try:
                resq = urllib.request.urlopen(
                    req, data=sendbytes, timeout=timeout).read()
                if resq == '':
                    raise Exception("无效返回")
                logger.info("response %s", resq)
                resq_dict = pickle.loads(resq)
                if resq_dict["status"] == "SUCCESS":
                    logger.info("succeed! post data(%s) to url(%s)", data,
                                self.url)
                    if "result" in resq_dict:
                        result = resq_dict["result"]
                    return result
                else:
                    logger.warning("failed! post data(%s) to url(%s)", data,
                                   self.url)
            except Exception as e:
                logger.exception("error! post data(%s) to url(%s), error(%s)",
                             data, self.url, str(e))
        return result


# 服务端使用此类继承
class HttpOnRecv(object):
    __metaclass__ = ABCMeta

    @abstractmethod
    def on_recv(self, data):
        pass


class MyHttpServerHandler(BaseHTTPRequestHandler):
    def __init__(self, request, client_address, server):
        BaseHTTPRequestHandler.__init__(self, request, client_address, server)
        self.server = server

    def _set_headers(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()

    # 暂时用不上
    def do_GET(self):
        response = {
            'status': 'SUCCESS',
            'data': 'hello from server'
        }

        self._set_headers()
        self.wfile.write(json.dumps(response))

    # 接收数据
    def do_POST(self):
        response = {'status': 'SUCCESS'}
        post_data = ""
        try:
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length).decode('utf-8')
            logger.info('获取到的数据：%s', post_data)

            # 确定下数据传输正确
            jsData = json.loads(post_data)
            if "data" not in jsData:
                raise Exception("接收结构异常，无data")
            if "md5" in jsData:
                # md5字段存在，则需要校验数据准确性
                data_expect_md5 = hashlib.md5(
                    jsData["data"].encode('utf8')).hexdigest()
                if str(data_expect_md5).lower() != jsData["md5"]:
                    raise Exception("数据MD5不对，需要重发")
            post_data = jsData["data"]
        except Exception as e:
            response["status"] = "FAIL"
            logger.exception("接收数据发生异常 %s", str(e))

        if (response["status"] == "SUCCESS" and
           self.server and self.server.on_recv):
            result = self.server.on_recv(post_data)
            if result:
                response["result"] = result

        self._set_headers()
        self.wfile.write(pickle.dumps(response))


class MyHttpServer(HTTPServer):
    def __init__(self, http_on_recv, server_address, RequestHandlerClass,
                 bind_and_activate=True):
        HTTPServer.__init__(self, server_address, RequestHandlerClass,
                            bind_and_activate)
        self.http_on_recv = http_on_recv

    def on_recv(self, data):
        return self.http_on_recv.on_recv(data)


class HttpReceiver(HttpOnRecv):
    def __init__(self, ip, port, on_recv_callback=None):
        self.ip = ip
        self.port = helpapi.normalize_port(port)
        self.on_recv_callback = on_recv_callback
        self.server = None

    # 这里接入回调信息
    def on_recv(self, data):
        result = None
        logger.info("收到数据：%s", data)
        if self.on_recv_callback:
            result = self.on_recv_callback(data)
        return result

    def run(self):
        try:
            self.server = MyHttpServer(self, (self.ip, self.port), MyHttpServerHandler)
            self.server.serve_forever()
        except Exception as e:
            logger.exception("error: %s", str(e))

    def shutdown(self):
        self.server.shutdown()


# 测试用例1
'''
def on_recv(data):
    logger.info("recv: %s", data)

import threading
import time

def test_http_receiver():
    http_receiver_handler = HttpReceiver('', 3600, on_recv)
    http_receiver_handler.run()

def test():
    try:
        t = threading.Thread(target=test_http_receiver)
        t.setDaemon(False)
        t.start()

        http_poster_handler = HttpPoster('http://127.0.0.1', 3600)
        while True:
            http_poster_handler.post_data('test')
            time.sleep(5)
    except Exception as e:
        pass

test()
'''

# 测试用例2
'''
import threading
import time

# 继承方式调用
class MyHttpReceiver(HttpReceiver):
    def on_recv(self, data):
        logger.info("my recv: %s", data)

def test_http_receiver():
    http_receiver_handler = MyHttpReceiver('10.16.104.46', 3600)
    http_receiver_handler.run()

def test():
    t = threading.Thread(target=test_http_receiver)
    t.setDaemon(False)
    t.start()

    http_poster_handler = HttpPoster('10.16.104.46', 3600)
    while True:
        http_poster_handler.post_data('test')
        time.sleep(5)

test()
'''
