#!/usr/bin/env python3
# coding=utf-8

import os
from abc import ABCMeta, abstractmethod

from src.common import txlog
from src.common.rpc import RpcServer, RpcClient
from src.common import helpapi

logger = txlog.getTxLogger()


# 实现一个文件传输服务，可以断点续传
class FileServer(object):
    def __init__(self, rootdir, host, port):
        logger.info('FileServer init rootdir=%s host=%s port=%s', rootdir,host, port)
        self.rootdir = rootdir
        self.rpc_helper = RpcServer(host, port)
        self.rpc_helper.add_method(self.get_file_info_from_name)
        self.rpc_helper.add_method(self.get_file_buffer)
        self.rpc_helper.start_serve()

    def get_file_buffer(self, uri, offset):
        result = {"status": "doing", "data": ""}
        # 读取对应的文件，按照偏移，读取8096
        filepath = os.path.join(self.rootdir, uri)
        try:
            f = open(filepath, 'rb')
            f.seek(offset, 0)
            result["data"] = f.read(8096)
            f.close()

            if len(result["data"]) < 8096:
                result["status"] = "finish"
        except Exception as e:
            logger.exception("error: %s", str(e))
        return result

    # 通过请求uri，获取文件信息，包括文件真实路径、md5、size
    def get_file_info_from_name(self, uri):
        result = {}
        # 读取对应的文件
        filepath = os.path.join(self.rootdir, uri)
        result["file"] = filepath
        result["md5"] = helpapi.big_file_md5(filepath)
        result["size"] = os.path.getsize(filepath)
        return result


# 文件传输进度
class FileOnRecv(object):
    __metaclass__ = ABCMeta

    @abstractmethod
    def on_progress(self, file, offset):
        pass

    def on_finish(self, file):
        pass


# 文件下载
class FileClient(object):
    def __init__(self, server_host, server_port):
        logger.info('FileClient init server_host=%s server_port=%s', server_host, server_port)
        self.rpc_helper = RpcClient(server_host, server_port)

    '''
    file：需要下载的文件路径
    savepath：存储的目标位置，可以是目录（文件名会以服务器返回的文件来存储），也可以是文件
    md5：如果调用者知道待下载的文件的md5（比如先前已经通过某种询问后台的方法获取到了），这里也需要对最终下载的文件做校验
    '''
    def download(self, file, savepath, md5=None):
        try:
            # 获取文件当前目录
            file_dir = ''
            file_path = ''
            if not os.path.exists(savepath):
                file_dir = savepath
            elif os.path.isdir(savepath):
                file_dir = savepath
            elif os.path.isfile(savepath):
                file_path = savepath
                file_dir = os.path.dirname(savepath)
            else:
                raise Exception("非文件或目录")

            # 拿file，去后台问文件基础信息（文件md5、真实文件名等）
            fileinfo = self.rpc_helper.call("FileServer.get_file_info_from_name", [file])
            if "file" not in fileinfo or "size" not in fileinfo or "md5" not in fileinfo:
                raise Exception("返回结果异常")
            if md5 is not None and md5.lower() != fileinfo["md5"].lower():
                raise Exception("url远端文件和md5对不上")
            if fileinfo["size"] == 0:
                raise Exception("文件尺寸为0")

            md5 = fileinfo["md5"].lower()
            if file_path == '':
                file_path = os.path.join(savepath, os.path.basename(fileinfo["file"]))
                if os.path.exists(file_path):
                    if md5 == helpapi.big_file_md5(file_path).lower():
                        logger.info("文件已存在")
                        return
                    os.remove(file_path)

            # 如果有缓存文件，则获取一下缓存文件的头几个字节，确认下md5对不对
            cache_file = os.path.join(file_dir, "%s.txhpdl" % fileinfo["md5"])
            '''
            if os.path.exists(cache_file):
                # 缓存文件存在，说明之前已经下载过了，这里读取缓存文件，增量下载
                with open(cache_file, 'rb', encoding="urf8") as f:
                    f.seek(0, 0)
                    totalsize = f.read(32)
                    offset = f.read(32)
                    if totalsize != fileinfo["size"] or offset > totalsize:
                        os.remove(cache_file)
            '''
            # 如果md5对，然后需要拿到分片偏移，告知服务器，需要按照这个偏移开始下载
            # 下载过程中，体现一下进度信息
            self.__download(cache_file, fileinfo["file"])

            # 文件下载结束，对比下md5对不对，不对的话，则文件应该是下载失败了
            cache_md5 = helpapi.big_file_md5(cache_file).lower()
            if cache_md5 != md5:
                raise Exception("md5不对, local_md5: %s, srv_md5: %s",
                                cache_md5, md5)

            # 文件下载结束，则直接存储到目标位置，并删除cachefile
            os.rename(cache_file, file_path)

        except Exception as e:
            logger.exception("error: %s", str(e))
            return -1
        return 0

    def __download(self, savepath, filepath):
        # 请求下载，告知对方offset
        # 等待对方回包内容，长度，以及是否结束
        # 如果结束，则退出下载
        try:
            dir = os.path.dirname(savepath)
            if not os.path.exists(dir):
                os.mkdir(dir)
            f = open(savepath, 'ab+')
            offset = f.tell()
            recv = self.rpc_helper.call("FileServer.get_file_buffer", [filepath, offset])
            recv_buf = recv["data"]
            if recv_buf != '' or recv_buf is not None:
                f.write(recv_buf)
                offset = f.tell()
                while recv["status"] != "finish":
                    recv = self.rpc_helper.call("FileServer.get_file_buffer", [filepath, offset])
                    recv_buf = recv["data"]
                    if recv_buf != '' or recv_buf is not None:
                        f.write(recv_buf)
                        offset = f.tell()
                    else:
                        break
            f.close()
        except Exception as e:
            logger.exception("error: %s", str(e))


# 测试用例
'''
import time

def test():
    file_server = FileServer("d:\\hp", '', 3601)
    file_dl = FileClient("127.0.0.1", 3601)

    while True:
        file_dl.download("crash分析基本步骤.doc", "d:\\hp\\mydir")
        time.sleep(1000)


test()
'''
