#!/usr/bin/env python3
# coding=utf-8

import json
import re
import os

from src.common import txlog


logger = txlog.getTxLogger()


# json配置解析，后面封装加解密
class CfgParser(object):
    def __init__(self, filepath):
        self.cfg_data = {}
        self.cfgpath = filepath
        self.load(self.cfgpath)

    def load(self, cfgpath):
        logger.info("cfgpath: %s", cfgpath)
        if not os.path.exists(self.cfgpath):
            logger.warn("%s not exist", self.cfgpath)
            self.cfg_data = {}
            return True
        try:
            f = open(self.cfgpath, 'r', encoding='utf8')
            self.cfg_data = json.load(f)
        except Exception as e:
            logger.exception("%s load error. %s", str(e))
            return False
        return True

    def rawdata(self):
        return self.cfg_data

    # key: []，传的是list支持多级访问
    def set_data(self, keys, data):
        if type(keys) != list:
            keys = [keys]
        subnode = self.cfg_data
        for i, subkey in enumerate(keys):
            if subkey == '':
                break
            if i < len(keys) - 1:
                if subkey not in subnode:
                    subnode[subkey] = {}
                    subnode = subnode[subkey]
                else:
                    subnode = subnode[subkey]
            else:
                subnode[subkey] = data

    def get_data(self, keys):
        if type(keys) != list:
            keys = [keys]
        data = None
        subnode = self.cfg_data
        for i, subkey in enumerate(keys):
            if subkey == '':
                break
            if i < len(keys) - 1:
                if subkey in subnode:
                    subnode = subnode[subkey]
            else:
                if subkey in subnode:
                    data = subnode[subkey]
        return data

    def save(self):
        with open(self.cfgpath, 'w', encoding='utf8') as f:
            json.dump(self.cfg_data, f, ensure_ascii=False, indent=1)


class KVCfgMgr(object):

    def __init__(self, cfgpath, sep='='):
        self.cfgpath = cfgpath
        self.sep = sep
        self.load_cfgs = []
        self.write_sep = sep[:1]
        self.load()

    def load(self):
        with open(self.cfgpath, mode='r') as f:
            for rawline in f.readlines():
                line = rawline.strip()
                if line != '' and not line.startswith('#'):
                    items = re.split(self.sep, line)
                    if len(items) >= 2:
                        sep_index = line.find(items[0]) + len(items[0])
                        line_sep = line[sep_index]
                        if len(items) > 2:
                            items[0] = line[:sep_index]
                            items[1] = line[sep_index+1:]
                            del items[2:]
                        key, value = items
                        self.load_cfgs.append([key, line_sep, value])
                        continue
                self.load_cfgs.append([rawline])

    def read(self, readkey):
        for items in self.load_cfgs:
            if len(items) == 3:
                key, sep, value = items
                if key == readkey:
                    return value
        return None

    def write(self, writekey, writeval):
        for items in self.load_cfgs:
            if len(items) == 3:
                if items[0] == writekey:
                    items[2] = writeval
                    return
        self.load_cfgs.append([writekey, self.write_sep, writeval])

    def save(self, path=None):
        savepath = path if path else self.cfgpath
        with open(savepath, mode='w+') as f:
            for items in self.load_cfgs:
                if len(items) == 3:
                    line = items[0] + items[1] + items[2]
                else:
                    line = items[0]
                if not line.endswith('\n'):
                    line += '\n'
                f.write(line)
            f.flush()
