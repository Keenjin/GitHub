#!/usr/bin/env python3
# coding=utf-8

from abc import ABCMeta, abstractmethod
import json
import threading

from src.common import txlog
from src.common import http_post_data

logger = txlog.getTxLogger()


# 调用某个api的时候，这里通过传入api的名字，以及对应的参数信息
class RpcClient(object):
    def __init__(self, server_host, server_port):
        logger.info('RpcClient init server_host=%s server_port=%s', server_host, server_port)
        self.http_poster_handler = http_post_data.HttpPoster(
            server_host, server_port)

    '''同步调用
    调用方法有两种：
    1、param参数使用list，对应调用api则按顺序取参数
    exp：call("start_kvm", [True, "testparam"])
         对应的函数原型 def start_kvm(bool, string):
                            pass
    2、param参数使用dict，对应调用api必须按照此参数命名，但是顺序可以任意
    exp：call("start_test", {"param1": True, "param2": "testparam"})
         对应的函数原型 def start_kvm(param2, param1):
                            pass
    '''
    def call(self, funcname, param):
        data = {"method": funcname, "param": param}
        return self.http_poster_handler.post_data(data, True, 10000)

    '''异步调用
    def on_response(dict):
        pass
    '''
    def call_async(self, funcname, param, on_response):
        threading.Thread(target=__call_async, args=(
            funcname, param, on_response), daemon=True).start()

    def __call_async(self, funcname, param, on_response):
        result = self.call(funcname, param)
        if callable(on_response):
            on_response(result)


class RpcServer(http_post_data.HttpOnRecv, threading.Thread):
    def __init__(self, host, port):
        logger.info('RpcServer init server_host=%s server_port=%s', host, port)
        self.host = host
        self.port = port
        self.funcs = {}
        self.http_receiver_handler = None
        threading.Thread.__init__(self)

    def start_serve(self):
        self.setDaemon(True)
        self.start()

    def stop_serve(self):
        self.http_receiver_handler.shutdown()

    def run(self):
        try:
            self.http_receiver_handler = http_post_data.HttpReceiver(
                self.host, self.port, self.on_recv)
            self.http_receiver_handler.run()
        except Exception as e:
            logger.exception("rpc结束, error: %s", str(e))


    '''
    1、method必须传入，可以是任意函数对象
    2、name可以是函数的别名，为了导出给调用者调用，防止类成员的函数名很奇怪。如果使用全局函数，则可以无需取别名
    '''
    def add_method(self, method, name=None):
        method_name = None
        if name is not None:
            self.funcs[name] = method
        elif hasattr(method, '__self__'):
            # 说明是一个类成员对象的方法
            method_name = method.__self__.__class__.__name__ + '.' + method.__name__
            self.funcs[method_name] = method
        else:
            self.funcs[method.__name__] = method

    def load_method_param(self, data):
        try:
            data_dict = json.loads(data)
            return data_dict["method"], data_dict["param"]
        except Exception as e:
            return None, None

    def on_recv(self, data):
        result = None
        logger.info("my recv: %s", data)
        method, param = self.load_method_param(data)
        if method not in self.funcs:
            logger.warn("method: %s 方法不存在", method)
            return None

        try:
            if isinstance(param, dict):
                result = self.funcs[method](**param)
            else:
                result = self.funcs[method](*param)
        except Exception as e:
            logger.exception("执行函数%s失败, error: %s", method, str(e))
        return result


# 双向RPC通信
class RpcTunel(object):
    def __init__(self, serverport, serverip, hostport, hostip=''):
        logger.info('serverport=%s serverip=%s hostport=%s hostip=%s', serverip, serverport, hostport, hostip)
        self.rpc_call = RpcClient(serverip, serverport)
        self.rpc_be_call = RpcServer(hostip, hostport)
        self.rpc_be_call.start_serve()

    def call(self, funcname, param):
        return self.rpc_call.call(funcname, param)

    def add_method(self, method, name=None):
        return self.rpc_be_call.add_method(method, name)

    def wait(self, timeout=None):
        self.rpc_be_call.join(timeout)

    def shutdown(self):
        self.rpc_be_call.stop_serve()


# 测试用例
'''
import time

def TestFunc(a, b):
    logger.info("%d + %d = %d", a, b, a+b)
    return a + b

def TestFunc1(param2, param1):
    logger.info("param1 = %d, param2 = %d", param1, param2)
    return True

def test():
    server = RpcServer('', 3601)
    server.add_method(TestFunc)
    server.add_method(TestFunc1)
    server.start_serve()

    client = RpcClient('http://127.0.0.1', 3601)
    while True:
        client.call("TestFunc", [1, 2])
        client.call("TestFunc1", {"param1": 1, "param2": 2})
        time.sleep(10)

# test()

def test1():
    node1 = RpcTunel(3601, 'http://127.0.0.1', 6613)
    node1.add_method(TestFunc)

    node2 = RpcTunel(6613, "http://127.0.0.1", 3601)
    node2.add_method(TestFunc1)

    result = {}
    while True:
        result = node1.call("TestFunc1", {"param1": 1, "param2": 2})
        logger.info('TestFunc1 return: %s', result)
        result = node2.call("TestFunc", [1, 2])
        logger.info('TestFunc return: %s', result)
        time.sleep(10)

# test1()

class TestApi(object):
    def test_add(self, a, b):
        logger.info("a+b=%d", a+b)
        return a + b

def test2():
    obj = TestApi()
    node1 = RpcTunel(3601, 'http://127.0.0.1', 6613)
    node1.add_method(obj.test_add)

    node2 = RpcTunel(6613, "http://127.0.0.1", 3601)
    node2.add_method(TestFunc1)

    result = {}
    while True:
        result = node1.call("TestFunc1", {"param1": 1, "param2": 2})
        logger.info('TestFunc1 return: %s', result)
        result = node2.call("TestApi.test_add", [1, 2])
        logger.info('TestApi.test_add return: %s', result)
        time.sleep(10)

test2()
'''

