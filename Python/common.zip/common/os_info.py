#!/usr/bin/env python3
# coding=utf-8

import platform
import distro

from src.common import txlog

logger = txlog.getTxLogger()


class OSInfo(object):
    os_info = {}

    @staticmethod
    def get_architecture():
        if "architecture" not in OSInfo.os_info:
            OSInfo.os_info["architecture"] = platform.machine()
        return OSInfo.os_info["architecture"]

    @staticmethod
    def get_os_name():
        if "os_name" not in OSInfo.os_info:
            name = ""
            if(platform.system() == "Linux"):
                name = distro.linux_distribution()[0]
            if (platform.system() == "Windows"):
                name = "Windows " + platform.win32_ver()[0]
            OSInfo.os_info["os_name"] = name
        return OSInfo.os_info["os_name"]

    @staticmethod
    def get_os_codename():
        if "os_codename" not in OSInfo.os_info:
            codename = ""
            if (platform.system() == "Linux"):
                codename = distro.linux_distribution()[2]
            if (platform.system() == "Windows"):
                codename = "Windows NT"
            OSInfo.os_info["os_codename"] = codename
        return OSInfo.os_info["os_codename"]

    @staticmethod
    def get_platform():
        if "platform" not in OSInfo.os_info:
            _platform = ""
            if("centos" in platform.platform().lower()):
                _platform = "centos"
            if ("debian" in platform.platform().lower()):
                _platform = "debian"
            if ("ubuntu" in platform.platform().lower()):
                _platform = "ubuntu"
            if ("windows" in platform.platform().lower()):
                _platform = "windows"
            OSInfo.os_info["platform"] = _platform
        return OSInfo.os_info["platform"]

    @staticmethod
    def get_version():
        if "version" not in OSInfo.os_info:
            version = ""
            if(platform.system() == "Linux"):
                version = distro.linux_distribution()[1]
            if (platform.system() == "Windows"):
                version = platform.win32_ver()[0]
            OSInfo.os_info["version"] = version
        return OSInfo.os_info["version"]

    @staticmethod
    def get_family():
        if "family" not in OSInfo.os_info:
            family = ""
            if ("centos" == OSInfo.get_platform()):
                family = "redhat"
            if ("windows" == OSInfo.get_platform()):
                family = "microsoft"
            if ("ubuntu" == OSInfo.get_platform()):
                family = "ubuntu"
            if ("debian" == OSInfo.get_platform()):
                family = "ubuntu"
            OSInfo.os_info["family"] = family
        return OSInfo.os_info["family"]

    @staticmethod
    def printInfo():
        logger.info("architecture : " + OSInfo.get_architecture())
        logger.info("version : " + OSInfo.get_version())
        logger.info("family : " + OSInfo.get_family())
        logger.info("name : " + OSInfo.get_os_name())
        logger.info("codename : " + OSInfo.get_os_codename())
        logger.info("platform : " + OSInfo.get_platform())


# test
'''
if __name__ == "__main__":
    OSInfo.printInfo()
'''
