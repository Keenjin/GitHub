#!/usr/bin/env python3
# coding=utf-8

from scapy.all import *
import socket


arptable = {}


class Pkthelper:
    def __init__(self):
        self.ifs = {}
        self.cb = None
        n = 0
        ifs = get_if_list()
        self.ipv4s = {}
        host = socket.getaddrinfo(socket.gethostname(),None)[-1][4][0]
        self.defaultindex = 0
        for id in ifs:
            tmp = id
            if conf.use_winpcapy:
                tmp = dev_from_pcapname(id)
            ip = get_if_addr(tmp)
            if ip == host:
                self.defaultindex = n
            self.ipv4s[ip] = n
            self.ifs[n] = id
            self.ifs[id] = {}
            n += 1

    def get_index_from_ipv4(self, ip):
        try:
            if ip is None or ip == '':
                return self.defaultindex
            return self.ipv4s[ip]
        except Exception as identifier:
            return self.defaultindex

    def cap(self, index=None, filter=None, cb=None):
        self.cb = cb
        if index is None:
            index = 0
        threading.Thread(target=self.run, args=(index, filter)).start()

    def run(self, index, filter):
        tmp = self.ifs[index]
        if conf.use_winpcapy:
            tmp = dev_from_pcapname(tmp)
        sniff(iface=tmp, filter=filter, prn=self.captcp)

    def captcp(self, pkt):
        if self.cb:
            self.cb(pkt.sniffed_on, pkt)
        eth = pkt
        ip4 = eth.payload if eth and eth.type == 0x0800 else None
        tcp = ip4.payload if ip4 and ip4.proto == 0x06 else None
        udp = ip4.payload if ip4 and ip4.proto == 0x11 else None
        if not eth or not ip4:
            return
        arptable[ip4.src] = eth.src
        arptable[ip4.dst] = eth.dst

    def getmac(self, ip):
        return arptable.get(ip, 'ff:ff:ff:ff:ff:ff')

    def fake_tcp(self, sip, dip, sport, dport, payload):
        smac = self.getmac(sip)
        dmac = self.getmac(dip)
        pkt = Ether(src=smac, dst=dmac) / IP(src=sip,dst=dip) / TCP(sport=sport,dport=dport,flags=2) / payload
        return raw(pkt)

    def send(self, bf, index=None):
        if index is None:
            index = 0
        tmp = self.ifs[index]
        if conf.use_winpcapy:
            tmp = dev_from_pcapname(tmp)
        sendp(Ether(bf), iface=tmp)
