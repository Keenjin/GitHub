#!/usr/bin/env python3
# coding=utf-8

import logging
from logging import handlers
import os
import platform
import time
import sys
sys.path.append(os.path.dirname(__file__))


class TXLOG(logging.RootLogger):
    def __init__(self, release=False):
        logging.RootLogger.__init__(self, level=logging.DEBUG)
        logging.Formatter.converter = time.localtime
        log_handler = None
        linefmt = "%(asctime)s.%(msecs)d [%(levelname)s] %(processName)s pid:%(process)d tid:%(thread)d %(funcName)s (%(filename)s:%(lineno)d) : %(message)s"
        datefmt = "%Y-%m-%d %H:%M:%S"

        logfile = ''
        if platform.system() == "Windows":
            logfile = os.getenv('PROGRAMDATA')
            if not logfile:
                logfile = 'c:\\programdata\\'
        else:
            logfile = '/var/log/'
        logfile = os.path.join(logfile, 'hp')
        logfile = os.path.join(logfile, 'hp.log')

        dirpath = os.path.dirname(logfile)
        if not os.path.exists(dirpath):
            os.mkdir(dirpath)
        log_handler = handlers.TimedRotatingFileHandler(
            filename=logfile, when='D', backupCount=5, encoding='utf-8')
        log_handler.setFormatter(logging.Formatter(linefmt, datefmt))

        # Release下，只打文件日志，且输出日志级别是WARNING；Debug下，打debug级别日志，且输出文件和控制台
        if release:
            log_handler.setLevel(logging.WARNING)
            self.addHandler(log_handler)
        else:
            log_handler.setLevel(logging.DEBUG)
            self.addHandler(log_handler)
            log_handler = logging.StreamHandler()
            log_handler.setLevel(logging.DEBUG)
            log_handler.setFormatter(logging.Formatter(linefmt, datefmt))
            self.addHandler(log_handler)


my_logger = None


# Release下，这里默认填充文件路径。Debug下，同时使用控制台和文件日志
def getTxLogger(release=False):
    global my_logger
    if not my_logger:
        my_logger = TXLOG(release)
        my_logger.info("===================== start =====================")
    return my_logger


# 测试用例
'''
def testTxLogger():
    txLogger = getTxLogger()
    txLogger.info("test")

testTxLogger()
'''
