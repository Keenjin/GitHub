#!/usr/bin/env python3
# coding=utf-8


import socket
import select
import threading
import txlog
import struct
import ctypes
import pickle
import os
from cfg_parser import CfgParser

logger = txlog.getTxLogger()


class IpcId(object):
    def __init__(self):
        self.cfg = CfgParser(os.path.join(os.path.dirname(__file__), 'ipc_id.json'))

    def port(self, name):
        port = self.cfg.get_data(["ports", name])
        return port

    def msg_id(self, msgname):
        msg = self.cfg.get_data(["msgs", msgname])
        return msg


ipc_id_cfg = IpcId()


class IpcComm(threading.Thread):
    def __init__(self, port, client_num=10, timeout=0.001):
        self.port = port
        self.client_num = client_num
        self.timeout = timeout
        self.active = True
        self.version = 1
        self.msg_fn = {}
        super(IpcComm, self).__init__()
        self.start()

    def register(self, msg, fn):
        if callable(fn):
            self.msg_fn[msg] = fn

    def unregister(self, msg):
        if msg in self.msg_fn:
            self.msg_fn.pop(msg)

    def run(self):
        try:
            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            srv.setblocking(False)
            srv.bind(('', self.port))
            srv.listen(self.client_num)
            rs_input = [srv]
            while self.active:
                rs, ws, es = select.select(rs_input, [], [], self.timeout)
                if not (rs or ws or es):
                    continue

                for s in rs:
                    if s is srv:
                        conn, client_addr = s.accept()
                        logger.info("%s 已连接", client_addr)
                        conn.setblocking(False)
                        rs_input.append(conn)
                    else:
                        try:
                            fmt = '!1B2H'
                            size = struct.calcsize(fmt)
                            buf = s.recv(size)
                            if buf:
                                # 有客户连接数据过来
                                version, msg, data_len = struct.unpack(fmt, buf)
                                logger.info("ver:%d msg:%d datalen:%d", version, msg, data_len)
                                if version != 1:
                                    s.close()
                                    raise Exception("版本号不对")
                                data = b''
                                if data_len > 0:
                                    data = s.recv(data_len)
                                result = self.__dispatch(msg, data)
                                s.sendall(self.__pack_data(msg, pickle.dumps(result)))
                            else:
                                # 断开连接，清除套接字
                                rs_input.remove(s)
                                s.close()
                                logger.info("断开连接")
                        except Exception as e:
                            logger.exception("异常 %s", str(e))
            for s in rs_input:
                try:
                    s.close()
                except Exception as e:
                    logger.exception("异常 %s", str(e))
                    pass
            logger.info("over.")
        except Exception as e:
            logger.exception("异常，port:%d, err:%s", self.port, str(e))

    def __dispatch(self, msg, data):
        result = {'status': 'Fail'}
        try:
            if msg in self.msg_fn:
                if len(data) > 0 and isinstance(data, bytes):
                    data = pickle.loads(data)
                res = self.msg_fn[msg](data)
                if isinstance(res, bool):
                    if res:
                        result['status'] = 'Succ'
                    else:
                        result['status'] = 'Fail'
                elif isinstance(res, tuple):
                    if res:
                        result['status'] = 'Succ'
                    else:
                        result['status'] = 'Fail'
                    result['resp'] = res[1]
            else:
                logger.warn("消息：%d未注册", msg)
        except Exception as e:
            logger.exception("异常, err:%s", str(e))
        return result

    def send(self, dst_port, msg, data=None, timeout=500):
        result = None
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setblocking(True)
            s.settimeout(timeout)
            s.connect(('127.0.0.1', dst_port))
            if data is None:
                data_bin = b''
            elif isinstance(data, str):
                data_bin = data.encode('utf-8')
            elif isinstance(data, dict):
                data_bin = pickle.dumps(data)
            else:
                raise Exception("data必须为str或dict")
            buf = self.__pack_data(msg, data_bin)
            s.sendall(buf)

            try:
                fmt = '!1B2H'
                size = struct.calcsize(fmt)
                buf = s.recv(size)
                if buf:
                    # 有客户连接数据过来
                    version, msg, data_len = struct.unpack(fmt, buf)
                    logger.info("ver:%d msg:%d datalen:%d", version, msg, data_len)
                    if version != 1:
                        s.close()
                        raise Exception("版本号不对")
                    if data_len > 0:
                        buf = s.recv(data_len)
                        data = pickle.loads(buf)
                        if data["status"] == "Succ":
                            logger.info("成功, data:%s", data)
                            if "resp" in data:
                                result = data["resp"]
                        else:
                            logger.warn("失败, data:%s", data)
                else:
                    raise Exception("无返回数据")
            except Exception as e:
                logger.exception("失败了, err:%s", str(e))
        except Exception as e:
            logger.exception("异常, port:%d, err:%s", self.port, str(e))
        s.close()
        return result

    def shutdown(self):
        self.active = False

    def __pack_data(self, msg, data):
        # |version|-------msg-------|------消息长度------|----------消息data-----------|
        # |  8位  |       16位      |        16位        |        0 ~ 65536位          |
        data_len = len(data)
        buf = ctypes.create_string_buffer(5+data_len)
        index = 0
        fmt = '!1B2H'
        struct.pack_into(fmt, buf, index, self.version, msg, data_len)
        index += struct.calcsize(fmt)
        fmt = '!' + str(data_len) + 's'
        struct.pack_into(fmt, buf, index, data)
        return buf

# 测试用例
'''
import time

def on_msg1(data):
    logger.info(data)
    return True

def on_msg2(data):
    logger.info(data)
    return True, 'some response data'


if __name__ == "__main__":
    node1 = IpcComm(4444)
    node1.register(1, on_msg1)
    node1.register(2, on_msg2)
    node2 = IpcComm(4445)
    node3 = IpcComm(4446)
    node4 = IpcComm(4447)
    node5 = IpcComm(4448)
    res = node1.send(4445, 1, '4445, hello world')
    if res is not None:
        logger.info(res)
    res = node2.send(4444, 1, '4444, hello world')
    if res is not None:
        logger.info(res)
    res = node3.send(4444, 2)
    if res is not None:
        logger.info(res)
    res = node4.send(4444, 1, '4444, hello world')
    res = node5.send(4444, 1, '4444, hello world')
    node1.shutdown()
    while True:
        time.sleep(10000)
'''
