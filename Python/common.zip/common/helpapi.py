#!/usr/bin/env python3
# coding=utf-8

import os
import platform
import hashlib

from src.common import txlog

logger = txlog.getTxLogger()


def big_file_md5(file):
    md5_value = hashlib.md5()
    with open(file, 'rb') as f:
        while True:
            data_flow = f.read(8096)
            if not data_flow:
                break
            md5_value.update(data_flow)
    return md5_value.hexdigest()


# 获取蜜罐的临时目录，windows下为：c:\programdata\hp，linux下为：/var/temp/hp
def get_app_tmp_path():
    temp_path = ''
    if platform.system() == "Windows":
        temp_path = os.getenv('PROGRAMDATA')
        if not temp_path:
            temp_path = 'c:\\programdata\\'
    else:
        temp_path = '/var/temp/'
    temp_path = os.path.join(temp_path, 'hp')
    return temp_path


def normalize_host(host):
    if type(host) != str:
        raise Exception("host请使用字符串")
        return ''
    if host.lower() == 'localhost':
        return host
    elif host != '' and host.lower()[0:4] != 'http':
        host = 'http://' + host
    return host


def normalize_port(port):
    if type(port) == str:
        return int(port)
    elif type(port) == int:
        return port
    raise Exception("端口异常，请使用str或int")


# 测试用例
'''
def test_big_file_md5():
    md5 = big_file_md5('C:\\Users\\xxxxxx.docx')
    logger.info("md5: %s", md5)

if __name__ == "__main__":
    test_big_file_md5()
'''
