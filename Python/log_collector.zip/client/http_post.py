#!/usr/bin/env python3
# coding=utf-8

import os
import logging
import urllib
import json
from urllib import request

logger = logging.getLogger(__name__)

class http_post(object):
    def __init__(self, host, port, try_cnt = 1):
        self.host = host
        self.port = port
        self.url = host + ":" + str(port)
        self.try_cnt = try_cnt

    def http_post_data(self, data):
        req = request.Request(self.url)
        req.add_header('Content-Type', 'application/json')
        #sendbytes = urllib.parse.urlencode(data).encode("utf-8")
        sendbytes = str(data).encode("utf-8")
        cnt = self.try_cnt
        while cnt > 0:
            cnt = cnt - 1
            try:
                resq = urllib.request.urlopen(req, data = sendbytes, timeout = 95).read().decode("utf-8")
                logger.info("response %s", resq)
                resq_dict = json.loads(resq)
                if resq_dict["status"] == "SUCCESS":
                    logger.info("succeed! post data(%s) to url(%s)", data, self.url)
                    return True
                else :
                    logger.warning("failed! post data(%s) to url(%s)", data, self.url)
            except Exception as e:
                logger.error("error! post data(%s) to url(%s), error(%s)", data, self.url, str(e))
        return False