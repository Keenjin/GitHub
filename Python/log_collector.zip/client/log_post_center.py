#!/usr/bin/env python3
# coding=utf-8

import os
import logging
import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from abc import ABCMeta, abstractmethod
import time
import hashlib

from log_cfg import log_cfg_parser
from http_post import http_post


logger = logging.getLogger(__name__)


class log_poster_on_change(object):
    __metaclass__ = ABCMeta

    def __init__(self):
        pass
    
    @abstractmethod
    def on_change(self, filename):
        pass

class FileChangeNotify(FileSystemEventHandler):
    def set_log_poster(self, log_poster_on_change):
        self.log_poster = log_poster_on_change

    def on_modified(self, event):
        logger.debug("path:%s changed!", event.src_path)
        self.log_poster.on_change(event.src_path) 

class log_poster(log_poster_on_change):
    def __init__(self):
        logger.info("begin log post!")
        try:
            self.cfg = log_cfg_parser("log_config.cfg")
            self.cfg_history = log_cfg_parser("log_history.cfg")
            self.http_post = http_post(self.cfg.data("server_host"), self.cfg.data("server_port"), self.cfg.data("http_post_try"))
        except Exception as e:
            logger.error("error: %s", str(e))

    def is_file_care(self, filepath):
        if os.path.exists(filepath):
            # 依次看一下监控目录，发现存在，则返回对应的协议类型
            if filepath.find(self.cfg.data("ssh", "log_dir")) != -1:
                return "ssh"
            if filepath.find(self.cfg.data("rdp", "log_dir")) != -1:
                return "ssh"
        return None

    def on_change(self, filename):
        protocol = self.is_file_care(filename)
        if protocol != None and protocol != "":
            self.post_file(protocol.lower(), filename.lower())
            self.cfg_history.save()

    def is_file_ext_care(self, file, ext):
        if ext == None or ext == "" or ext == "*":
            return True
        if os.path.splitext(file)[-1] == ext:
            return True
        return False

    def post_file(self, protocol, filepath):
        ret = False
        if self.is_file_ext_care(filepath, self.cfg.data(protocol, "log_ext")):
            offset = self.cfg_history.data(protocol, filepath, "offset")
            if offset == "" or offset == None:
                offset = 0
            with open(filepath, 'r') as f:
                f.seek(offset, 0)
                last_offset = offset
                line = f.readline()
                while line:
                    # 如果发送失败了，就只讲offset记录到当前位置
                    data = {"protocol":protocol, "log_time":int(round(time.mktime(time.localtime(os.stat(filepath).st_mtime)))), "log_line_md5":hashlib.md5(line.encode('utf8')).hexdigest(), "log_line":line}
                    if not self.http_post.http_post_data(data):
                        offset = last_offset
                        break
                    else :
                        offset = f.tell()
                        last_offset = offset
                        ret = True
                    line = f.readline()
            self.cfg_history.set_data(offset, protocol, filepath, "offset")
        return ret

    def check_history_ssh(self):
        # 首先，需要遍历ssh的监控目录，有几个文件，然后看一下history中的某些文件的offset，seek到具体位置，然后发送数据
        path = self.cfg.data("ssh", "log_dir")
        if path == None or not os.path.exists(path):
            return
        
        for dirpath,dirnames,filenames in os.walk(path):
            for file in filenames:
                filepath = os.path.join(dirpath, file).lower()
                self.post_file("ssh", filepath)
                
        self.cfg_history.save()

    def check_history_rdp(self):
        pass
    
    def check_history(self):
        self.check_history_ssh()
        self.check_history_rdp()

    def run(self):
        # 首先，检查所有的文件，发现不一致的，直接发数据
        self.check_history()

        # 设置看门狗，监控文件改变
        event_handler = FileChangeNotify()
        event_handler.set_log_poster(self)
        observer = Observer()
        
        try:
            listen_dir_cnt = 0
            # 分别监控SSH、RDP等目录
            path = self.cfg.data("ssh", "log_dir")
            if os.path.exists(path):
                observer.schedule(event_handler, path=path, recursive=True)
                listen_dir_cnt = listen_dir_cnt + 1
            
            path = self.cfg.data("rdp", "log_dir")
            if os.path.exists(path):
                observer.schedule(event_handler, path=path, recursive=True)
                listen_dir_cnt = listen_dir_cnt + 1
            
            if listen_dir_cnt > 0:
                observer.start()

            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            observer.stop()
        observer.join()