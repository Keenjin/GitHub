#!/usr/bin/env python3
# coding=utf-8

import os
from sys import argv
import json
from log_collector.client.log_post_center import log_poster

'''
    step1：读log_config.cfg、log_history.cfg
    step2：check一下log文件，是否有变化；有变化，add到处理函数（文件名）
    step3：处理函数（文件名，配置里的offset），然后fseek到offset位置，开始readline，走到step6
    step4：设置监控目录
    step5：监控目录，当有发生目录文件变更的，匹配是否关心文件；若为关心的文件，则直接add到处理函数（文件名），走到step3
    step6：调用http_post接口发送数据（重试2次），发送成功返回新的offset给处理函数
'''
def main(argv):
    log_poster_handle = log_poster()
    log_poster_handle.run()

if __name__ == "__main__":
    main(argv)