#!/usr/bin/env python3
# coding=utf-8

import os
import json
import logging

logger = logging.getLogger(__name__)

class log_cfg_parser(object):
    def __init__(self, filename):
        self.cfgpath = os.path.join(os.path.split(os.path.realpath(__file__))[0], filename)
        self.load(self.cfgpath)
    
    def load(self, cfgpath):
        if not os.path.exists(self.cfgpath):
            logger.warn("%s not exist", self.cfgpath)
            self.cfg_data = {}
            return True
        with open(self.cfgpath, 'r') as f:
            self.cfg_data = json.load(f)
        return True

    def rawdata(self):
        return self.cfg_data

    def set_data(self, data, key1 = None, key2 = None, key3 = None):
        if key1 == None:
            return
        if key2 == None:
            self.cfg_data[key1] = data
        elif key3 == None:
            self.cfg_data[key1] = {key2:data}
        else:
            self.cfg_data[key1] = {key2:{key3:data}}

    def data(self, key1 = None, key2 = None, key3 = None):
        if key1 == "" or key1 == None:
            return ""
        if key1 in self.cfg_data:
            if key2 == "" or key2 == None or key2 not in self.cfg_data[key1]:
                return self.cfg_data[key1]
            elif key3 == "" or key3 == None or key3 not in self.cfg_data[key1][key2]:
                return self.cfg_data[key1][key2]
            else :
                return self.cfg_data[key1][key2][key3]
        else:
            return ""

    def save(self):
        with open(self.cfgpath, 'w') as f:
            json.dump(self.cfg_data, f)