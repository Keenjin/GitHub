#!/usr/bin/env python3
# coding=utf-8

import logging
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from abc import ABCMeta, abstractmethod
import hashlib

from log_collector.server.log_cfg import log_cfg_parser

logger = logging.getLogger(__name__)

class log_on_recv(object):
    __metaclass__ = ABCMeta    
    @abstractmethod
    def on_recv(self, data):
        pass

class log_http_server_handler(BaseHTTPRequestHandler):

    log_on_recver = None

    def _set_headers(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()

    @staticmethod
    def set_log_on_recv(log_on_recv):
        log_http_server_handler.log_on_recver = log_on_recv

    # 暂时用不上
    def do_GET(self):
        response = {
            'status':'SUCCESS',
            'data':'hello from server'
        }

        self._set_headers()
        self.wfile.write(json.dumps(response))

    def check_data(self, data):
        ret = False
        try:
            data_dict = json.loads(data)
            data_md5 = hashlib.md5(data_dict["log_line"].encode('utf8')).hexdigest()
            if str(data_md5).lower() == data_dict["log_line_md5"]:
                ret = True
        except Exception as e:
            ret = False
            logger.error("发生异常 %s", str(e))
        return ret        

    # 接收数据
    def do_POST(self):
        response = {'status':'SUCCESS'}
        post_data = ""
        try:
            content_length = int(self.headers['Content-Length'])
            #post_data = urllib.parse.unquote(self.rfile.read(content_length).decode('utf-8'), 'utf-8')
            post_data = self.rfile.read(content_length).decode('utf-8')
            post_data = post_data.replace("'",'"')
            logger.debug('获取到的数据：%s', post_data)

            # 确定下数据传输正确
            if not self.check_data(post_data):
                response["status"] = "FAIL"
        except Exception as e:
            response["status"] = "FAIL"
            logger.error("接收数据发生异常 %s", str(e))
        
        self._set_headers()
        self.wfile.write(json.dumps(response).encode("utf-8"))

        if response["status"] == "SUCCESS" and log_http_server_handler.log_on_recver:
            log_http_server_handler.log_on_recver.on_recv(post_data)

class log_receiver(log_on_recv):
    def __init__(self):
        self.cfg = log_cfg_parser("conf.cfg")
    
    # 这里接入seedsnie的日志分析中心
    def on_recv(self, data):
        logger.info("收到数据：%s", data)
        print(data)

    def run(self):
        server = HTTPServer(('', self.cfg.data("log_port")), log_http_server_handler)
        server.RequestHandlerClass.set_log_on_recv(self)
        server.serve_forever()
