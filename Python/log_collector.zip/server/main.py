#!/usr/bin/env python3
# coding=utf-8

from sys import argv
import os

from log_collector.server.log_recv_center import log_receiver

def main(argv):
    log_receiver_handler = log_receiver()
    log_receiver_handler.run()

if __name__ == "__main__":
    main(argv)